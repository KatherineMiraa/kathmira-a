﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using CaguiclaLawrenceWebsite.Models;
//using ContosoCrafts.WebSite.Services;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;

//namespace CaguiclaLawrenceWebsite.Controllers
//{
//    [Route("[controller]")]
//   [ApiController]
//    public class ProductsController : ControllerBase
//    {
//        public ProductsController(JsonFileProductService productService)
//        {
//            this.ProductService = productService;
//        }
//
 //       public JsonFileProductService ProductService { get; }
//    }

//    public JsonFileProductService productService;

 //   public JsonFileProductService GetProductService()
//    {
//        return this.ProductService;
//    }

 //   [HttpGet]
 //   public IEnumerable<Product> Get()
 //   {
//        return ProductService.GetProducts();
//    }
//}